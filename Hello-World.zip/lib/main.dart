import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue[900],
          title: Text('Hi-Kod'),
          leading: Icon(Icons.menu),
          actions: [
            IconButton(
              icon: Icon(Icons.person), // İnsan ikonu
              onPressed: () {
                // İnsan ikonuna tıklandığında konsola mesaj yazdır
                print('İnsan ikonuna tıklandı!');
              },
            ),
          ],
        ),
        body: Center(
          child: ElevatedButton(
            onPressed: () {
              // Butona basıldığında yapılacaklar
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue, // Buton rengi
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30.0), // Oval buton
              ),
              padding: EdgeInsets.symmetric(horizontal: 30, vertical: 20),
            ),
            child: Text(
              'Hello World',
              style: TextStyle(
                fontSize: 20,
                color: Colors.white,
              ),
            ),
          ),
        ),
        backgroundColor: Colors.lightBlueAccent[100], // Arka plan rengi
      ),
    );
  }
}
